﻿/*
Copyright © from 2024 to present, UNKNOWN STRYKER (Hojin Lee / Joey). All Rights Reserved.

Licensed under the Frogman Engine License (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	https://github.com/UnknownStryker-Interactive-Technologies/Frogman-Engine-License/blob/release/LICENSE.md

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
#ifndef _PONG_COMPONENTS_HPP_
#define _PONG_COMPONENTS_HPP_

#include <FE/prerequisites.hxx>
#include <FE/framework/reflection.hxx>

#include "PongWorld.hpp"


// Every type below is an EnTT component. They are attached with
// FE::world::add_component<T>() and iterated with FE::world::get_components_view<T...>().
// They hold data only; all behaviour lives in the systems in PongSystems.hpp.
BEGIN_NAMESPACE(pong)


// Court space position. Shared by the ball, both paddles and the net.
FE_STRUCT();
struct transform_2d
{
	FHT_GENERATED();
	var::float32 _x = 0.0f;
	var::float32 _y = 0.0f;
};


// World units per second. Only the ball and a moving paddle carry one.
FE_STRUCT();
struct velocity_2d
{
	FHT_GENERATED();
	var::float32 _vx = 0.0f;
	var::float32 _vy = 0.0f;
};


// Axis aligned half extent used by the paddle sweep.
FE_STRUCT();
struct box_collider_2d
{
	FHT_GENERATED();
	var::float32 _half_width = 0.0f;
	var::float32 _half_height = 0.0f;
};


// The ball is the only round collider on the court.
FE_STRUCT();
struct circle_collider_2d
{
	FHT_GENERATED();
	var::float32 _radius = 0.0f;
};


// Marks an entity as a paddle and carries the numbers the movement system needs.
FE_STRUCT();
struct paddle
{
	FHT_GENERATED();
	PaddleSide _side = PaddleSide::_Left;
	var::float32 _move_speed = 14.0f;
	var::float32 _last_contact_offset = 0.0f;
};


// Marks the ball and carries the rally state that survives a bounce.
FE_STRUCT();
struct ball
{
	FHT_GENERATED();
	var::float32 _speed = 0.0f;
	var::uint32 _consecutive_hits = 0;
	PaddleSide _serving_towards = PaddleSide::_Right;
};


// One frame worth of local player intent. The input systems write it, the paddle
// movement system reads it and the edge flags are cleared at the end of the frame.
FE_STRUCT();
struct player_intent
{
	FHT_GENERATED();
	var::float32 _vertical_axis = 0.0f;
	var::boolean _serve_pressed = false;
	var::boolean _pause_pressed = false;
};


// Attached to the paddle the CPU drives instead of player_intent.
FE_STRUCT();
struct cpu_brain
{
	FHT_GENERATED();
	OpponentSkill _skill = OpponentSkill::_Rookie;
	var::float32 _reaction_delay_seconds = 0.18f;
	var::float32 _reaction_timer = 0.0f;
	var::float32 _tracking_speed = 9.0f;
	var::float32 _aim_error = 0.75f;
	var::float32 _target_y = 0.0f;
};


// Written by the sweep systems and consumed by the bounce system in the same
// physics step. It is removed from the ball entity once it has been applied.
FE_STRUCT();
struct bounce_event
{
	FHT_GENERATED();
	BounceSurface _surface = BounceSurface::_None;
	var::float32 _contact_offset = 0.0f;
	var::float32 _impact_speed = 0.0f;
	var::float32 _time_of_impact = 0.0f;
};


// The position the ball held at the start of the physics step, used for the swept
// test so a fast ball cannot tunnel through a paddle.
FE_STRUCT();
struct previous_transform_2d
{
	FHT_GENERATED();
	var::float32 _x = 0.0f;
	var::float32 _y = 0.0f;
};


// Anything the renderer should draw. The draw queue is built from a view over
// transform_2d and sprite_quad.
FE_STRUCT();
struct sprite_quad
{
	FHT_GENERATED();
	var::float32 _half_width = 0.5f;
	var::float32 _half_height = 0.5f;
	var::uint32 _rgba = 0xFFFFFFFF;
	var::uint16 _layer = 0;
	var::boolean _is_visible = true;
};


// The net is drawn as a dashed column down the centre line.
FE_STRUCT();
struct net_strip
{
	FHT_GENERATED();
	var::uint16 _segment_count = 15;
	var::float32 _segment_gap = 0.4f;
	var::float32 _blink_phase = 0.0f;
};


// Lives on the match entity. The scoring systems are the only writers.
FE_STRUCT();
struct match_score
{
	FHT_GENERATED();
	var::uint8 _left_points = 0;
	var::uint8 _right_points = 0;
	var::uint8 _points_to_win = 11;
	var::uint8 _winning_margin = 2;
};


// Also lives on the match entity. _serve_countdown is ticked down while the rally
// state is _WaitingForServe.
FE_STRUCT();
struct rally_clock
{
	FHT_GENERATED();
	RallyState _state = RallyState::_WaitingForServe;
	var::float32 _elapsed_seconds = 0.0f;
	var::float32 _serve_countdown = 0.0f;
	var::uint32 _hit_count = 0;
	PaddleSide _next_server = PaddleSide::_Left;
};


// The per match statistics the result screen reads back.
FE_STRUCT();
struct match_report
{
	FHT_GENERATED();
	var::uint32 _longest_rally_hits = 0;
	var::float32 _longest_rally_seconds = 0.0f;
	var::float32 _fastest_ball_speed = 0.0f;
	PaddleSide _winner = PaddleSide::_Left;
};


END_NAMESPACE
#endif // _PONG_COMPONENTS_HPP_
